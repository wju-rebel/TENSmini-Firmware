/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.h
  * @brief          : Header for main.c file.
  *                   This file contains the common defines of the application.
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2024 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */

/* Define to prevent recursive inclusion -------------------------------------*/
#ifndef __MAIN_H
#define __MAIN_H

#ifdef __cplusplus
extern "C" {
#endif

/* Includes ------------------------------------------------------------------*/
#include "stm32l4xx_hal.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */

/* USER CODE END Includes */

/* Exported types ------------------------------------------------------------*/
/* USER CODE BEGIN ET */
/**
* @brief  Pulse frequency, ranging from 1 Hz to 1000 Hz.
*/
typedef enum
{
  FREQ_1HZ		= 0x0001U,  /*!< Pulse frequency = 1   Hz	*/
  FREQ_2HZ		= 0x0002U,  /*!< Pulse frequency = 2   Hz	*/
  FREQ_3HZ		= 0x0003U,  /*!< Pulse frequency = 3   Hz	*/
  FREQ_4HZ		= 0x0004U,  /*!< Pulse frequency = 4   Hz	*/
  FREQ_5HZ		= 0x0005U,  /*!< Pulse frequency = 5   Hz	*/
  FREQ_6HZ		= 0x0006U,  /*!< Pulse frequency = 6   Hz	*/
  FREQ_7HZ		= 0x0007U,  /*!< Pulse frequency = 7   Hz	*/
  FREQ_8HZ		= 0x0008U,  /*!< Pulse frequency = 8   Hz	*/
  FREQ_9HZ		= 0x0009U,  /*!< Pulse frequency = 9   Hz	*/
  FREQ_10HZ		= 0x000AU,  /*!< Pulse frequency = 10  Hz	*/
  FREQ_11HZ		= 0x000BU,  /*!< Pulse frequency = 11  Hz	*/
  FREQ_12HZ		= 0x000CU,  /*!< Pulse frequency = 12  Hz	*/
  FREQ_13HZ		= 0x000DU,  /*!< Pulse frequency = 13  Hz	*/
  FREQ_14HZ		= 0x000EU,  /*!< Pulse frequency = 14  Hz	*/
  FREQ_15HZ 	= 0x000FU,  /*!< Pulse frequency = 15  Hz	*/
  FREQ_16HZ		= 0x0010U,  /*!< Pulse frequency = 16  Hz	*/
  FREQ_17H		= 0x0011U,  /*!< Pulse frequency = 17  Hz	*/
  FREQ_18HZ		= 0x0012U,  /*!< Pulse frequency = 18  Hz	*/
  FREQ_19HZ		= 0x0013U,  /*!< Pulse frequency = 19  Hz	*/
  FREQ_20HZ		= 0x0014U,  /*!< Pulse frequency = 20  Hz	*/
  FREQ_21HZ		= 0x0015U,  /*!< Pulse frequency = 21  Hz	*/
  FREQ_22HZ		= 0x0016U,  /*!< Pulse frequency = 22  Hz	*/
  FREQ_23HZ		= 0x0017U,  /*!< Pulse frequency = 23  Hz	*/
  FREQ_24HZ		= 0x0018U,  /*!< Pulse frequency = 24  Hz	*/
  FREQ_25HZ		= 0x0019U,  /*!< Pulse frequency = 25  Hz	*/
  FREQ_26HZ		= 0x001AU,  /*!< Pulse frequency = 26  Hz	*/
  FREQ_27HZ		= 0x001BU,  /*!< Pulse frequency = 27  Hz	*/
  FREQ_28HZ		= 0x001CU,  /*!< Pulse frequency = 28  Hz	*/
  FREQ_29HZ		= 0x001DU,  /*!< Pulse frequency = 29  Hz	*/
  FREQ_30HZ		= 0x001EU,  /*!< Pulse frequency = 30  Hz	*/
  FREQ_31HZ		= 0x001FU,  /*!< Pulse frequency = 31  Hz	*/
  FREQ_32HZ		= 0x0020U,  /*!< Pulse frequency = 32  Hz	*/
  FREQ_33HZ		= 0x0021U,  /*!< Pulse frequency = 33  Hz	*/
  FREQ_34HZ		= 0x0022U,  /*!< Pulse frequency = 34  Hz	*/
  FREQ_35HZ		= 0x0023U,  /*!< Pulse frequency = 35  Hz	*/
  FREQ_36HZ		= 0x0024U,  /*!< Pulse frequency = 36  Hz	*/
  FREQ_37HZ		= 0x0025U,  /*!< Pulse frequency = 37  Hz	*/
  FREQ_38HZ		= 0x0026U,  /*!< Pulse frequency = 38  Hz	*/
  FREQ_39HZ		= 0x0027U,  /*!< Pulse frequency = 39  Hz	*/
  FREQ_40HZ		= 0x0028U,  /*!< Pulse frequency = 40  Hz	*/
  FREQ_41HZ		= 0x0029U,  /*!< Pulse frequency = 41  Hz	*/
  FREQ_42HZ		= 0x002AU,  /*!< Pulse frequency = 42  Hz	*/
  FREQ_43HZ		= 0x002BU,  /*!< Pulse frequency = 43  Hz	*/
  FREQ_44HZ		= 0x002CU,  /*!< Pulse frequency = 44  Hz	*/
  FREQ_45HZ		= 0x002DU,  /*!< Pulse frequency = 45  Hz	*/
  FREQ_46HZ		= 0x002EU,  /*!< Pulse frequency = 46  Hz	*/
  FREQ_47HZ		= 0x002FU,  /*!< Pulse frequency = 47  Hz	*/
  FREQ_48HZ		= 0x0030U,  /*!< Pulse frequency = 48  Hz	*/
  FREQ_49HZ		= 0x0031U,  /*!< Pulse frequency = 49  Hz	*/
  FREQ_50HZ		= 0x0032U,  /*!< Pulse frequency = 50  Hz	*/
  FREQ_51HZ		= 0x0033U,  /*!< Pulse frequency = 51  Hz	*/
  FREQ_52HZ		= 0x0034U,  /*!< Pulse frequency = 52  Hz	*/
  FREQ_53HZ		= 0x0035U,  /*!< Pulse frequency = 53  Hz	*/
  FREQ_54HZ		= 0x0036U,  /*!< Pulse frequency = 54  Hz	*/
  FREQ_55HZ		= 0x0037U,  /*!< Pulse frequency = 55  Hz	*/
  FREQ_56HZ		= 0x0038U,  /*!< Pulse frequency = 56  Hz	*/
  FREQ_57HZ		= 0x0039U,  /*!< Pulse frequency = 57  Hz	*/
  FREQ_58HZ		= 0x003AU,  /*!< Pulse frequency = 58  Hz	*/
  FREQ_59HZ		= 0x003BU,  /*!< Pulse frequency = 59  Hz	*/
  FREQ_60HZ		= 0x003CU,  /*!< Pulse frequency = 60  Hz	*/
  FREQ_61HZ		= 0x003DU,  /*!< Pulse frequency = 61  Hz	*/
  FREQ_62HZ		= 0x003EU,  /*!< Pulse frequency = 62  Hz	*/
  FREQ_63HZ		= 0x003FU,  /*!< Pulse frequency = 63  Hz	*/
  FREQ_64HZ		= 0x0040U,  /*!< Pulse frequency = 64  Hz	*/
  FREQ_65HZ		= 0x0041U,  /*!< Pulse frequency = 65  Hz	*/
  FREQ_66HZ		= 0x0042U,  /*!< Pulse frequency = 66  Hz	*/
  FREQ_67HZ		= 0x0043U,  /*!< Pulse frequency = 67  Hz	*/
  FREQ_68HZ		= 0x0044U,  /*!< Pulse frequency = 68  Hz	*/
  FREQ_69HZ		= 0x0045U,  /*!< Pulse frequency = 69  Hz	*/
  FREQ_70HZ		= 0x0046U,  /*!< Pulse frequency = 70  Hz	*/
  FREQ_71HZ		= 0x0047U,  /*!< Pulse frequency = 71  Hz	*/
  FREQ_72HZ		= 0x0048U,  /*!< Pulse frequency = 72  Hz	*/
  FREQ_73HZ		= 0x0049U,  /*!< Pulse frequency = 73  Hz	*/
  FREQ_74HZ		= 0x004AU,  /*!< Pulse frequency = 74  Hz	*/
  FREQ_75HZ		= 0x004BU,  /*!< Pulse frequency = 75  Hz	*/
  FREQ_76HZ		= 0x004CU,  /*!< Pulse frequency = 76  Hz	*/
  FREQ_77HZ		= 0x004DU,  /*!< Pulse frequency = 77  Hz	*/
  FREQ_78HZ		= 0x004EU,  /*!< Pulse frequency = 78  Hz	*/
  FREQ_79HZ		= 0x004FU,  /*!< Pulse frequency = 79  Hz	*/
  FREQ_80HZ		= 0x0050U,  /*!< Pulse frequency = 80  Hz	*/
  FREQ_81HZ		= 0x0051U,  /*!< Pulse frequency = 81  Hz	*/
  FREQ_82HZ		= 0x0052U,  /*!< Pulse frequency = 82  Hz	*/
  FREQ_83HZ		= 0x0053U,  /*!< Pulse frequency = 83  Hz	*/
  FREQ_84HZ		= 0x0054U,  /*!< Pulse frequency = 84  Hz	*/
  FREQ_85HZ		= 0x0055U,  /*!< Pulse frequency = 85  Hz	*/
  FREQ_86HZ		= 0x0056U,  /*!< Pulse frequency = 86  Hz	*/
  FREQ_87HZ		= 0x0057U,  /*!< Pulse frequency = 87  Hz	*/
  FREQ_88HZ		= 0x0058U,  /*!< Pulse frequency = 88  Hz	*/
  FREQ_89HZ		= 0x0059U,  /*!< Pulse frequency = 89  Hz	*/
  FREQ_90HZ		= 0x005AU,  /*!< Pulse frequency = 90  Hz	*/
  FREQ_91HZ		= 0x005BU,  /*!< Pulse frequency = 91  Hz	*/
  FREQ_92HZ		= 0x005CU,  /*!< Pulse frequency = 92  Hz	*/
  FREQ_93HZ		= 0x005DU,  /*!< Pulse frequency = 93  Hz	*/
  FREQ_94HZ		= 0x005EU,  /*!< Pulse frequency = 94  Hz	*/
  FREQ_95HZ		= 0x005FU,  /*!< Pulse frequency = 95  Hz	*/
  FREQ_96HZ		= 0x0060U,  /*!< Pulse frequency = 96  Hz	*/
  FREQ_97HZ		= 0x0061U,  /*!< Pulse frequency = 97  Hz	*/
  FREQ_98HZ		= 0x0062U,  /*!< Pulse frequency = 98  Hz	*/
  FREQ_99HZ		= 0x0063U,  /*!< Pulse frequency = 99  Hz	*/
  FREQ_100HZ	= 0x0064U,  /*!< Pulse frequency = 100 Hz	*/
  FREQ_150HZ	= 0x0096U,  /*!< Pulse frequency = 150 Hz	*/
  FREQ_200HZ	= 0x00C8U,  /*!< Pulse frequency = 200 Hz	*/
  FREQ_250HZ	= 0x00FAU,  /*!< Pulse frequency = 250 Hz	*/
  FREQ_300HZ	= 0x012CU,  /*!< Pulse frequency = 300 Hz	*/
  FREQ_350HZ	= 0x015EU,  /*!< Pulse frequency = 350 Hz	*/
  FREQ_400HZ	= 0x0190U,  /*!< Pulse frequency = 400 Hz	*/
  FREQ_450HZ	= 0x01C2U,  /*!< Pulse frequency = 400 Hz	*/
  FREQ_500HZ	= 0x01F4U,  /*!< Pulse frequency = 400 Hz	*/
  FREQ_1KHZ		= 0x03E8U,  /*!< Pulse frequency = 400 Hz	*/
} DDS_PulseFreqTypeDef;

/**
  * @brief  Pulse width, ranging from 25 us to 1000 us (1 ms).
  */
typedef enum
{
  PULSE_WIDTH_25US	= 0x0019U,  /*!< Pulse width = 25  us	*/
  PULSE_WIDTH_50US	= 0x0032U,  /*!< Pulse width = 50  us	*/
  PULSE_WIDTH_75US	= 0x004BU,  /*!< Pulse width = 75  us	*/
  PULSE_WIDTH_100US	= 0x0064U,  /*!< Pulse width = 100 us	*/
  PULSE_WIDTH_125US	= 0x007DU,  /*!< Pulse width = 125 us	*/
  PULSE_WIDTH_150US = 0x0096U,  /*!< Pulse width = 150 us	*/
  PULSE_WIDTH_175US = 0x00AFU,  /*!< Pulse width = 175 us	*/
  PULSE_WIDTH_200US = 0x00C8U,  /*!< Pulse width = 200 us	*/
  PULSE_WIDTH_225US = 0x00E1U,  /*!< Pulse width = 200 us	*/
  PULSE_WIDTH_250US = 0x00FAU,  /*!< Pulse width = 200 us	*/
  PULSE_WIDTH_275US = 0x0113U,  /*!< Pulse width = 200 us	*/
  PULSE_WIDTH_300US = 0x012CU,  /*!< Pulse width = 200 us	*/
  PULSE_WIDTH_325US = 0x0145U,  /*!< Pulse width = 200 us	*/
  PULSE_WIDTH_350US = 0x015EU,  /*!< Pulse width = 200 us	*/
  PULSE_WIDTH_375US = 0x0177U,  /*!< Pulse width = 200 us	*/
  PULSE_WIDTH_400US = 0x0190U,  /*!< Pulse width = 200 us	*/
  PULSE_WIDTH_425US = 0x01A9U,  /*!< Pulse width = 200 us	*/
  PULSE_WIDTH_450US = 0x01C2U,  /*!< Pulse width = 200 us	*/
  PULSE_WIDTH_475US = 0x01D8U,  /*!< Pulse width = 200 us	*/
  PULSE_WIDTH_500US = 0x01F4U,  /*!< Pulse width = 200 us	*/
  PULSE_WIDTH_1MS 	= 0x03E8U,  /*!< Pulse width = 200 us	*/
} DDS_PulseWidthTypeDef;

/**
  * @brief  Electrodes connection status.
  */
typedef enum
{
  Connected			= 0x0U,  /*!< Electrodes are connected.		*/
  Disconnected	= 0x1U,  /*!< Electrodes are disconnected.	*/
} Status_ElectrodeConnection;

/**
  * @brief  System status.
  */
typedef enum
{
  Stop	= 0x0U,  /*!< Emergency Stop		*/
	Start	= 0x1U,  /*!< System Carry On		*/
} Status_System;

/* USER CODE END ET */

/* Exported constants --------------------------------------------------------*/
/* USER CODE BEGIN EC */

/* USER CODE END EC */

/* Exported macro ------------------------------------------------------------*/
/* USER CODE BEGIN EM */

/* USER CODE END EM */

/* Exported functions prototypes ---------------------------------------------*/
void Error_Handler(void);

/* USER CODE BEGIN EFP */

/* USER CODE END EFP */

/* Private defines -----------------------------------------------------------*/
#define STIM_START_Pin GPIO_PIN_0
#define STIM_START_GPIO_Port GPIOB
#define STIM_LOPWR_Pin GPIO_PIN_1
#define STIM_LOPWR_GPIO_Port GPIOB
#define ELCTRD_CONN_Pin GPIO_PIN_2
#define ELCTRD_CONN_GPIO_Port GPIOB
#define ELCTRD_DISC_Pin GPIO_PIN_10
#define ELCTRD_DISC_GPIO_Port GPIOB
#define LED_TEST_Pin GPIO_PIN_3
#define LED_TEST_GPIO_Port GPIOB

/* USER CODE BEGIN Private defines */
/**
  * @brief  DAC value.
  */
//#define DACVAL_40MA			(2691)
//#define DACVAL_1MA			(624)
//#define DACVAL_0MA			(0)
//#define DACVAL_ITV			(53)
#define DACVAL_60MA			(3620)
//#define DACVAL_40MA			(4000)
#define DACVAL_1MA			(80)
#define DACVAL_0MA			(0)
#define DACVAL_ITV			(60)

/**
  * @brief  Length of Look-Up Tables.
  */
#define	FULL_LENGTH_LUT			(10000)
#define	HALF_LENGTH_LUT			(5000)
#define	SHORT_LENGTH_LUT		(1000)

#define FREQ_COMPENSATOR_1_9HZ		(2)
#define	FREQ_COMPENSATOR_10_99HZ	(2)
#define	FREQ_COMPENSATOR_100_1KHZ	(10)


/**
  * @brief  ADC value.
  */
#define ADCVAL_MIN						(0)
#define ADCVAL_THD						(274)+200 // [(9.5-8.8)*(18k/(39k+18k))] / (3.3/4096) = 274
//#define ADCVAL_THD						(0) // [(9.5-8.8)*(18k/(39k+18k))] / (3.3/4096) = 274
#define ADCVAL_MAX						(4095)

/**
  * @brief  Length of ADC Buffer Table.
  */
#define ADC_RX_BUFFER_LEN			(4095)
//#define ADC_RX_BUFFER_LEN		(1)
/* USER CODE END Private defines */

#ifdef __cplusplus
}
#endif

#endif /* __MAIN_H */
