/* USER CODE BEGIN Header */
/**
  ******************************************************************************
  * @file           : main.c
  * @brief          : Main program body
  ******************************************************************************
  * @attention
  *
  * Copyright (c) 2024 STMicroelectronics.
  * All rights reserved.
  *
  * This software is licensed under terms that can be found in the LICENSE file
  * in the root directory of this software component.
  * If no LICENSE file comes with this software, it is provided AS-IS.
  *
  ******************************************************************************
  */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"
#include "adc.h"
#include "dac.h"
#include "dma.h"
#include "tim.h"
#include "usart.h"
#include "gpio.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */
#include <stdio.h>
#include <string.h>
#include <math.h>
/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */

/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/

/* USER CODE BEGIN PV */
//uint8_t rx_buff_usart1[13] 	= {0x0D,0x0A,0x49,0x4D,0x5F,0,0,0,0,0x3A,0x38,0x0D,0x0A};
uint8_t rx_buff_usart1[13]  = {0};
uint8_t rx_buff_usart[1]    = {0};
uint8_t rx_buff_usart2[10] 	= {0};  //  creating a buffer of 10 bytes
uint8_t tx_buff_usart1[13] 	= {0};
char tx_buff_usart2[9]  		= {'T','E','S','T',' ','O','K','\r','\n'};

char freq_s[16];
char pulseW_s[16];
char current_s[16];
char dacVal_s[16];

//DAC Value
uint16_t current = 0;
uint16_t dacVal = DACVAL_0MA;										// 0mA
uint16_t freq = FREQ_10HZ;										  // 10Hz
uint16_t pulseW = PULSE_WIDTH_200US;						// 200us

//DAC Look-Up Table
volatile uint32_t Waveform_LUT[HALF_LENGTH_LUT] = {0};
volatile uint32_t Syncwave_LUT[HALF_LENGTH_LUT] = {0};

//System Status Check
Status_System sysStatus = Start;

//ADC Value
uint16_t adcVal = ADCVAL_MIN;										// value = 0
//ADC Rx Buffer
uint16_t i = 0;
uint8_t adc_flag = 0;
uint16_t ADC_RX_BUFFER[ADC_RX_BUFFER_LEN];
//Electrodes Connection Status Check
Status_ElectrodeConnection eletrdConStatus = Connected;

/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
/* USER CODE BEGIN PFP */
void delay_us(uint16_t time);
void delay_ms(uint16_t time);
void DDS_WaveLUT(uint16_t freq, uint16_t pulseWidth, uint32_t pulseLength, uint16_t DAC_Val);
void DDS_WaveLUT_1Hz(uint16_t freq, uint16_t pulseWidth, uint32_t pulseLength, uint16_t DAC_Val);
void DDS_SyncLUT(uint16_t freq, uint16_t pulseWidth, uint32_t pulseLength);
void DDS_Start(uint16_t freq, uint16_t pulseWidth, uint16_t DAC_Val);
void DDS_Stop(void);
uint16_t FIND_MIN(uint16_t array[], uint16_t length);
void Check_Connection(void);

/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */

/* USER CODE END 0 */

/**
  * @brief  The application entry point.
  * @retval int
  */
int main(void)
{
  /* USER CODE BEGIN 1 */
	//delay_ms(100);
	//HAL_Delay(100);
  /* USER CODE END 1 */

  /* MCU Configuration--------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* USER CODE BEGIN Init */
	//delay_ms(100);
	//HAL_Delay(100);
  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */

  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_DMA_Init();
  MX_DAC1_Init();
  MX_ADC1_Init();
  MX_TIM2_Init();
  MX_TIM6_Init();
  MX_USART1_UART_Init();
  MX_USART2_UART_Init();
  /* USER CODE BEGIN 2 */
	//HAL_UART_Receive_DMA(&huart1, rx_buff_usart1, sizeof(rx_buff_usart1));
	HAL_UART_Receive_DMA(&huart1, rx_buff_usart, sizeof(rx_buff_usart));
	//HAL_UART_Receive_DMA(&huart2, rx_buff_usart2, sizeof(rx_buff_usart2));
	HAL_ADC_Start_DMA(&hadc1, (uint32_t*)ADC_RX_BUFFER, ADC_RX_BUFFER_LEN);
	HAL_TIM_Base_Start(&htim2);

  /* USER CODE END 2 */

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */
  while (1)
  {
    /* USER CODE END WHILE */

    /* USER CODE BEGIN 3 */
		//delay_ms(10);
		//HAL_IWDG_Refresh(&hiwdg);
		//HAL_GPIO_WritePin(ELCTRD_DISC_GPIO_Port, ELCTRD_DISC_Pin, GPIO_PIN_SET);
		if (sysStatus == Start && adc_flag == 0)
		{
			//HAL_GPIO_WritePin(STIM_START_GPIO_Port, STIM_START_Pin, GPIO_PIN_SET);		//stim on
			HAL_GPIO_WritePin(STIM_LOPWR_GPIO_Port, STIM_LOPWR_Pin, GPIO_PIN_RESET);
			//HAL_GPIO_WritePin(ELCTRD_CONN_GPIO_Port, ELCTRD_CONN_Pin, GPIO_PIN_SET);
			HAL_GPIO_WritePin(ELCTRD_DISC_GPIO_Port, ELCTRD_DISC_Pin, GPIO_PIN_RESET);
		}
		else if (sysStatus == Stop && adc_flag == 0)
		{
			HAL_GPIO_WritePin(STIM_START_GPIO_Port, STIM_START_Pin, GPIO_PIN_RESET);
			HAL_GPIO_TogglePin(STIM_LOPWR_GPIO_Port, STIM_LOPWR_Pin);
			delay_ms(100);
			//HAL_GPIO_WritePin(ELCTRD_CONN_GPIO_Port, ELCTRD_CONN_Pin, GPIO_PIN_RESET);
			HAL_GPIO_WritePin(ELCTRD_DISC_GPIO_Port, ELCTRD_DISC_Pin, GPIO_PIN_RESET);
		}

		else if (sysStatus == Start && adc_flag == 1)
		{
			//HAL_GPIO_WritePin(STIM_START_GPIO_Port, STIM_START_Pin, GPIO_PIN_RESET);
			HAL_GPIO_WritePin(STIM_LOPWR_GPIO_Port, STIM_LOPWR_Pin, GPIO_PIN_RESET);
			//HAL_GPIO_WritePin(ELCTRD_CONN_GPIO_Port, ELCTRD_CONN_Pin, GPIO_PIN_RESET);
			HAL_GPIO_WritePin(ELCTRD_DISC_GPIO_Port, ELCTRD_DISC_Pin, GPIO_PIN_SET);
		}

		else if (sysStatus == Stop && adc_flag == 1)
		{
			HAL_GPIO_WritePin(STIM_START_GPIO_Port, STIM_START_Pin, GPIO_PIN_RESET);
			HAL_GPIO_TogglePin(STIM_LOPWR_GPIO_Port, STIM_LOPWR_Pin);
			delay_ms(100);
			//HAL_GPIO_WritePin(ELCTRD_CONN_GPIO_Port, ELCTRD_CONN_Pin, GPIO_PIN_RESET);
			HAL_GPIO_WritePin(ELCTRD_DISC_GPIO_Port, ELCTRD_DISC_Pin, GPIO_PIN_SET);
		}


  }
  /* USER CODE END 3 */
}

/**
  * @brief System Clock Configuration
  * @retval None
  */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  /** Configure the main internal regulator output voltage
  */
  if (HAL_PWREx_ControlVoltageScaling(PWR_REGULATOR_VOLTAGE_SCALE1) != HAL_OK)
  {
    Error_Handler();
  }

  /** Initializes the RCC Oscillators according to the specified parameters
  * in the RCC_OscInitTypeDef structure.
  */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_MSI;
  RCC_OscInitStruct.MSIState = RCC_MSI_ON;
  RCC_OscInitStruct.MSICalibrationValue = 0;
  RCC_OscInitStruct.MSIClockRange = RCC_MSIRANGE_6;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_MSI;
  RCC_OscInitStruct.PLL.PLLM = 1;
  RCC_OscInitStruct.PLL.PLLN = 40;
  RCC_OscInitStruct.PLL.PLLP = RCC_PLLP_DIV7;
  RCC_OscInitStruct.PLL.PLLQ = RCC_PLLQ_DIV2;
  RCC_OscInitStruct.PLL.PLLR = RCC_PLLR_DIV2;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }

  /** Initializes the CPU, AHB and APB buses clocks
  */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK|RCC_CLOCKTYPE_SYSCLK
                              |RCC_CLOCKTYPE_PCLK1|RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV1;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_4) != HAL_OK)
  {
    Error_Handler();
  }
}

/* USER CODE BEGIN 4 */
/** @brief Artificial Delayed Function - for micro-second level
  * @retval None
  */
void delay_us(uint16_t time)
{
	uint16_t i = 0;
	while (time--)
	{
		i = 10;
		while (i--);
	}
}

/** @brief Artificial Delayed Function - for milli-second level
  * @retval None
  */
void delay_ms(uint16_t time)
{
	uint16_t i = 0;
	while (time--)
	{
		i = 12000;
		while (i--);
	}
}

/** @brief Start DDS
  * @retval None
  */
void DDS_Start(uint16_t freq, uint16_t pulseWidth, uint16_t DAC_Val)
{
	if (freq == 1)
	{
		TIM6 -> PSC = 80 - 1;
    TIM6 -> ARR = 100 * FREQ_COMPENSATOR_1_9HZ / freq - 1;
		DDS_WaveLUT_1Hz(freq, pulseWidth, HALF_LENGTH_LUT, DAC_Val);
		HAL_DAC_Start_DMA(&hdac1, DAC_CHANNEL_1, (uint32_t*)Waveform_LUT, HALF_LENGTH_LUT, DAC_ALIGN_12B_R); /*!< 2048 bits one-off sending*/
		HAL_TIM_Base_Start(&htim6);
	}


  else if (freq >= 2 && freq < 10)

  {
    TIM6 -> PSC = 80 - 1;
    TIM6 -> ARR = 100 * FREQ_COMPENSATOR_1_9HZ / freq - 1;
		
//		TIM1 -> PSC = 8000 - 1;
//		TIM1 -> ARR = round(10000.0 / (freq));
//		TIM1 -> CCR1 = 50;

    DDS_WaveLUT(freq, pulseWidth, HALF_LENGTH_LUT, DAC_Val);
		DDS_SyncLUT(freq, 3000, HALF_LENGTH_LUT);
    HAL_DAC_Start_DMA(&hdac1, DAC_CHANNEL_1, (uint32_t*)Waveform_LUT, HALF_LENGTH_LUT, DAC_ALIGN_12B_R); /*!< 2048 bits one-off sending*/
		HAL_DAC_Start_DMA(&hdac1, DAC_CHANNEL_2, (uint32_t*)Syncwave_LUT, HALF_LENGTH_LUT, DAC_ALIGN_12B_R); /*!< 2048 bits one-off sending*/
		HAL_TIM_Base_Start(&htim6);
//		HAL_TIM_PWM_Start(&htim1, TIM_CHANNEL_1);
  }

  else if (freq >= 10 && freq <= 100)
  {
    TIM6 -> PSC = 1 - 1;
    TIM6 -> ARR = 8000 * FREQ_COMPENSATOR_10_99HZ / freq - 1;
		
//		TIM1 -> PSC = 80 - 1;
//		TIM1 -> ARR = round(1000000.0 / (freq)) - 1;
//		TIM1 -> CCR1 = 50;

    DDS_WaveLUT(freq, pulseWidth, HALF_LENGTH_LUT, DAC_Val);
		DDS_SyncLUT(freq, 1000, HALF_LENGTH_LUT);
    HAL_DAC_Start_DMA(&hdac1, DAC_CHANNEL_1, (uint32_t*)Waveform_LUT, HALF_LENGTH_LUT, DAC_ALIGN_12B_R); /*!< 2048 bits one-off sending*/
		HAL_DAC_Start_DMA(&hdac1, DAC_CHANNEL_2, (uint32_t*)Syncwave_LUT, HALF_LENGTH_LUT, DAC_ALIGN_12B_R); /*!< 2048 bits one-off sending*/
		HAL_TIM_Base_Start(&htim6);
//		HAL_TIM_PWM_Start(&htim1, TIM_CHANNEL_1);
  }

  else if (freq >= 100 && freq <= 1000)
  {
    TIM6 -> PSC = 1 - 1;
    TIM6 -> ARR = 8000 * FREQ_COMPENSATOR_100_1KHZ / freq - 1;
		
//		TIM1 -> PSC = 80 - 1;
//		TIM1 -> ARR = round(1000000.0 / (freq)) - 1;
//		TIM1 -> CCR1 = 50;

    DDS_WaveLUT(freq, pulseWidth, HALF_LENGTH_LUT, DAC_Val);
		DDS_SyncLUT(freq, 3000, SHORT_LENGTH_LUT);
    HAL_DAC_Start_DMA(&hdac1, DAC_CHANNEL_1, (uint32_t*)Waveform_LUT, SHORT_LENGTH_LUT, DAC_ALIGN_12B_R); /*!< 2048 bits one-off sending*/
		HAL_DAC_Start_DMA(&hdac1, DAC_CHANNEL_2, (uint32_t*)Syncwave_LUT, SHORT_LENGTH_LUT, DAC_ALIGN_12B_R); /*!< 2048 bits one-off sending*/
		HAL_TIM_Base_Start(&htim6);
//		HAL_TIM_PWM_Start(&htim1, TIM_CHANNEL_1);
  }

  else
  {
    DDS_Stop();
  }
}

/**
  * @brief Stop DDS
  * @retval None
  */
void DDS_Stop(void)
{
  HAL_TIM_Base_Stop(&htim6);
  HAL_DAC_Stop_DMA(&hdac1, DAC_CHANNEL_1);
}

/**
  * @brief Make a look-up table (LUT) for DDS
  * @retval None
  */
void DDS_WaveLUT(uint16_t freq, uint16_t pulseWidth, uint32_t pulseLength, uint16_t DAC_Val)
{
  uint32_t i;
  for(i = 0; i < round(pulseWidth/(1000000.0/freq/(pulseLength-1))); i++)
  {
    Waveform_LUT[i]= DAC_Val;
  }
  for(; i < pulseLength; i++)
  {
    Waveform_LUT[i]= 0;
  }
}

/**
  * @brief Make a look-up table (LUT) for DDS - 1 Hz
  * @retval None
  */
void DDS_WaveLUT_1Hz(uint16_t freq, uint16_t pulseWidth, uint32_t pulseLength, uint16_t DAC_Val)
{
  uint32_t i_1Hz;
	//uint32_t j_1Hz;
	pulseW = PULSE_WIDTH_150US;
  for(i_1Hz = 0; i_1Hz < round(2*pulseWidth/(1000000.0/freq/(pulseLength-1))); i_1Hz++)
  {
    Waveform_LUT[i_1Hz]= DAC_Val;
  }
  for(; i_1Hz < pulseLength*2; i_1Hz++)
  {
    Waveform_LUT[i_1Hz]= 0;
  }
//	for(j_1Hz = 0; j_1Hz < pulseLength; j_1Hz++)
//  {
//    Waveform_LUT[i_1Hz+j_1Hz]= 0;
//  }
}

/**
  * @brief Make a look-up table (LUT) for DDS
  * @retval None
  */
void DDS_SyncLUT(uint16_t freq, uint16_t pulseWidth, uint32_t pulseLength)
{
  uint32_t j;
  for(j = 0; j < round(pulseWidth/(1000000.0/freq/(pulseLength-1))); j++)
  {
    Syncwave_LUT[j]= ADCVAL_MAX;
  }
  for(; j < pulseLength; j++)
  {
    Syncwave_LUT[j]= 0;
  }
}

/**
  * @brief USART Call Back
  * @retval None
  */
//手机通过蓝牙助手通过USART1发送一位数据给MCU,然后MCU通过USART2(Virtual COM)跟PC通讯,
//直接发送MCU收到的数据
void HAL_UART_RxCpltCallback(UART_HandleTypeDef *huart)
{
	if (huart->Instance == USART1)
	{
		/* Emergency STOP!
		*/
		if (rx_buff_usart[0] == 'a')
		{	
			dacVal = DACVAL_0MA;
			current = 0;
			sysStatus = Stop;
			//HAL_GPIO_WritePin(STIM_LOPWR_GPIO_Port, STIM_LOPWR_Pin, GPIO_PIN_SET);
			//HAL_GPIO_WritePin(ELCTRD_DISC_GPIO_Port, ELCTRD_DISC_Pin, GPIO_PIN_SET);
			//HAL_GPIO_WritePin(STIM_START_GPIO_Port, STIM_START_Pin, GPIO_PIN_RESET);
			DDS_Stop();
		}

		/*
		if ((rx_buff_usart1[5] == 0x0A) && (rx_buff_usart1[6] == 0x0A) && (rx_buff_usart1[7] == 0x0A) && (rx_buff_usart1[8] == 0x0A))
		{	
			dacVal = DACVAL_0MA;
			current = 0;
			sysStatus = Stop;
			//HAL_GPIO_WritePin(STIM_LOPWR_GPIO_Port, STIM_LOPWR_Pin, GPIO_PIN_SET);
			//HAL_GPIO_WritePin(ELCTRD_DISC_GPIO_Port, ELCTRD_DISC_Pin, GPIO_PIN_SET);
			//HAL_GPIO_WritePin(STIM_START_GPIO_Port, STIM_START_Pin, GPIO_PIN_RESET);
			DDS_Stop();
		}
		*/
/*
		else if ((rx_buff_usart1[5] == 0x44) && (rx_buff_usart1[6] == 0x49) && (rx_buff_usart1[7] == 0x53) && (rx_buff_usart1[8] == 0x43))
		{	
			dacVal = DACVAL_0MA;
			current = 0;
			sysStatus = Stop;
			//HAL_GPIO_WritePin(STIM_LOPWR_GPIO_Port, STIM_LOPWR_Pin, GPIO_PIN_RESET);
			//HAL_GPIO_WritePin(ELCTRD_DISC_GPIO_Port, ELCTRD_DISC_Pin, GPIO_PIN_RESET);
			//HAL_GPIO_WritePin(STIM_START_GPIO_Port, STIM_START_Pin, GPIO_PIN_RESET);
			DDS_Stop();
		}
		
		else if ((rx_buff_usart1[5] == 0x43) && (rx_buff_usart1[6] == 0x4F) && (rx_buff_usart1[7] == 0x4E) && (rx_buff_usart1[8] == 0x4E))
		{	
			dacVal = DACVAL_0MA;
			current = 0;
			sysStatus = Start;
			//HAL_GPIO_WritePin(STIM_LOPWR_GPIO_Port, STIM_LOPWR_Pin, GPIO_PIN_RESET);
			//HAL_GPIO_WritePin(ELCTRD_DISC_GPIO_Port, ELCTRD_DISC_Pin, GPIO_PIN_RESET);
			//HAL_GPIO_WritePin(STIM_START_GPIO_Port, STIM_START_Pin, GPIO_PIN_RESET);
			DDS_Stop();
		}
*/		
		else
		{
			sysStatus = Start;
			//HAL_GPIO_WritePin(STIM_LOPWR_GPIO_Port, STIM_LOPWR_Pin, GPIO_PIN_RESET);
			//HAL_GPIO_WritePin(ELCTRD_DISC_GPIO_Port, ELCTRD_DISC_Pin, GPIO_PIN_RESET);
		}
			
		if (sysStatus == !Stop)
		{	
			/* LED Test Only - Turn on
			*/
			if (rx_buff_usart[0] == 'b')
			{
				//HAL_GPIO_WritePin(STIM_START_GPIO_Port, STIM_START_Pin, GPIO_PIN_SET);
				adc_flag = 0;
				HAL_GPIO_WritePin(LED_TEST_GPIO_Port, LED_TEST_Pin, GPIO_PIN_SET);
			}
			/*
			if ((rx_buff_usart1[5] == 0x01) && (rx_buff_usart1[6] == 0x01) && (rx_buff_usart1[7] == 0x01) && (rx_buff_usart1[8] == 0x01))
			{
				//HAL_GPIO_WritePin(STIM_START_GPIO_Port, STIM_START_Pin, GPIO_PIN_SET);
				adc_flag = 0;
				HAL_GPIO_WritePin(LED_TEST_GPIO_Port, LED_TEST_Pin, GPIO_PIN_SET);
			}
			*/

			/* LED Test Only - Turn off
			*/
			else if (rx_buff_usart[0] == 'c')
			{
				//HAL_GPIO_WritePin(STIM_START_GPIO_Port, STIM_START_Pin, GPIO_PIN_SET);
				adc_flag = 0;
				HAL_GPIO_WritePin(LED_TEST_GPIO_Port, LED_TEST_Pin, GPIO_PIN_RESET);
			}

			/*
			else if ((rx_buff_usart1[5] == 0x02) && (rx_buff_usart1[6] == 0x02) && (rx_buff_usart1[7] == 0x02) && (rx_buff_usart1[8] == 0x02))
			{
				//HAL_GPIO_WritePin(STIM_START_GPIO_Port, STIM_START_Pin, GPIO_PIN_SET);
				adc_flag = 0;
				HAL_GPIO_WritePin(LED_TEST_GPIO_Port, LED_TEST_Pin, GPIO_PIN_RESET);
			}
			*/
			
			/* Increase Intensity
			*/
			else if (rx_buff_usart[0] == '1')
			{
				HAL_GPIO_WritePin(STIM_START_GPIO_Port, STIM_START_Pin, GPIO_PIN_SET);
				adc_flag = 0;
				HAL_ADC_Start_DMA(&hadc1, (uint32_t*)ADC_RX_BUFFER, ADC_RX_BUFFER_LEN);
				if (dacVal < DACVAL_1MA)
				{
					dacVal = DACVAL_1MA;
					current = 1;
				}
				else if ((dacVal >= DACVAL_1MA) && (dacVal < DACVAL_60MA))
				{
					dacVal += DACVAL_ITV;
					current += 1;
				}			
			}

			/*
			else if ((rx_buff_usart1[5] == 0x0B) && (rx_buff_usart1[6] == 0x0B) && (rx_buff_usart1[7] == 0x0B) && (rx_buff_usart1[8] == 0x0B))
			{
				HAL_GPIO_WritePin(STIM_START_GPIO_Port, STIM_START_Pin, GPIO_PIN_SET);
				adc_flag = 0;
				HAL_ADC_Start_DMA(&hadc1, (uint32_t*)ADC_RX_BUFFER, ADC_RX_BUFFER_LEN);
				if (dacVal < DACVAL_1MA)
				{
					dacVal = DACVAL_1MA;
					current = 1;
				}
				else if ((dacVal >= DACVAL_1MA) && (dacVal < DACVAL_60MA))
				{
					dacVal += DACVAL_ITV;
					current += 1;
				}			
			}
			*/
			/* Decrease Intensity
			*/
			else if (rx_buff_usart[0] == '2')
			{
				HAL_GPIO_WritePin(STIM_START_GPIO_Port, STIM_START_Pin, GPIO_PIN_SET);
				adc_flag = 0;
				HAL_ADC_Start_DMA(&hadc1, (uint32_t*)ADC_RX_BUFFER, ADC_RX_BUFFER_LEN);
				if ((dacVal > DACVAL_1MA) && (dacVal <= DACVAL_60MA))
				{
					dacVal -= DACVAL_ITV;
					current -= 1;
				}
				else if (dacVal <= DACVAL_1MA)
				{
					dacVal = DACVAL_0MA;
					current = 0;
				}
			}
			/*
			else if ((rx_buff_usart1[5] == 0x0C) && (rx_buff_usart1[6] == 0x0C) && (rx_buff_usart1[7] == 0x0C) && (rx_buff_usart1[8] == 0x0C))
			{
				HAL_GPIO_WritePin(STIM_START_GPIO_Port, STIM_START_Pin, GPIO_PIN_SET);
				adc_flag = 0;
				HAL_ADC_Start_DMA(&hadc1, (uint32_t*)ADC_RX_BUFFER, ADC_RX_BUFFER_LEN);
				if ((dacVal > DACVAL_1MA) && (dacVal <= DACVAL_60MA))
				{
					dacVal -= DACVAL_ITV;
					current -= 1;
				}
				else if (dacVal <= DACVAL_1MA)
				{
					dacVal = DACVAL_0MA;
					current = 0;
				}
			}
			*/
			/* Increase Frequency
			*/
			else if (rx_buff_usart[0] == '3')
			{
				HAL_GPIO_WritePin(STIM_START_GPIO_Port, STIM_START_Pin, GPIO_PIN_SET);
				adc_flag = 0;
				HAL_ADC_Start_DMA(&hadc1, (uint32_t*)ADC_RX_BUFFER, ADC_RX_BUFFER_LEN);
				if ((freq >= FREQ_1HZ) && (freq < FREQ_2HZ))
				{
					freq += 1;
					if (freq == 2)
						pulseW = PULSE_WIDTH_200US;
				}
				else if ((freq >= FREQ_2HZ) && (freq < FREQ_5HZ))
					freq += 3;
				else if ((freq >= FREQ_5HZ) && (freq < FREQ_25HZ))
					freq += 5;
			}
			/*
			else if ((rx_buff_usart1[5] == 0x0D) && (rx_buff_usart1[6] == 0x0D) && (rx_buff_usart1[7] == 0x0D) && (rx_buff_usart1[8] == 0x0D))
			{
				HAL_GPIO_WritePin(STIM_START_GPIO_Port, STIM_START_Pin, GPIO_PIN_SET);
				adc_flag = 0;
				HAL_ADC_Start_DMA(&hadc1, (uint32_t*)ADC_RX_BUFFER, ADC_RX_BUFFER_LEN);
				if ((freq >= FREQ_1HZ) && (freq < FREQ_2HZ))
					freq += 1;
				else if ((freq >= FREQ_2HZ) && (freq < FREQ_5HZ))
					freq += 3;
				else if ((freq >= FREQ_5HZ) && (freq < FREQ_25HZ))
					freq += 5;
			}
			*/
			/* Decrease Frequency
			*/
			else if (rx_buff_usart[0] == '4')
			{
				HAL_GPIO_WritePin(STIM_START_GPIO_Port, STIM_START_Pin, GPIO_PIN_SET);
				adc_flag = 0;
				HAL_ADC_Start_DMA(&hadc1, (uint32_t*)ADC_RX_BUFFER, ADC_RX_BUFFER_LEN);
				if ((freq > FREQ_1HZ) && (freq <= FREQ_2HZ))
				{
					freq -= 1;
					if (freq == 1)
						pulseW = PULSE_WIDTH_150US;
				}
				else if ((freq > FREQ_2HZ) && (freq <= FREQ_5HZ))
					freq -= 3;
				else if ((freq > FREQ_5HZ) && (freq <= FREQ_25HZ))
					freq -= 5;
			}
			/*
			else if ((rx_buff_usart1[5] == 0x1D) && (rx_buff_usart1[6] == 0x1D) && (rx_buff_usart1[7] == 0x1D) && (rx_buff_usart1[8] == 0x1D))
			{
				HAL_GPIO_WritePin(STIM_START_GPIO_Port, STIM_START_Pin, GPIO_PIN_SET);
				adc_flag = 0;
				HAL_ADC_Start_DMA(&hadc1, (uint32_t*)ADC_RX_BUFFER, ADC_RX_BUFFER_LEN);
				if ((freq > FREQ_1HZ) && (freq <= FREQ_2HZ))
					freq -= 1;
				else if ((freq > FREQ_2HZ) && (freq <= FREQ_5HZ))
					freq -= 3;
				else if ((freq > FREQ_5HZ) && (freq <= FREQ_25HZ))
					freq -= 5;
			}
			*/
			/* Increase Pulse Width
			*/
			else if (rx_buff_usart[0] == '5')
			{
				HAL_GPIO_WritePin(STIM_START_GPIO_Port, STIM_START_Pin, GPIO_PIN_SET);
				adc_flag = 0;
				HAL_ADC_Start_DMA(&hadc1, (uint32_t*)ADC_RX_BUFFER, ADC_RX_BUFFER_LEN);

				if ((pulseW >= PULSE_WIDTH_50US) && (pulseW < PULSE_WIDTH_250US))
				{
					if (freq == 1)
						pulseW = PULSE_WIDTH_150US;
					else if (freq == 2)
						pulseW = PULSE_WIDTH_200US;
					else
						pulseW += 50;
				}
			}
			/*
			else if ((rx_buff_usart1[5] == 0x0E) && (rx_buff_usart1[6] == 0x0E) && (rx_buff_usart1[7] == 0x0E) && (rx_buff_usart1[8] == 0x0E))
			{
				HAL_GPIO_WritePin(STIM_START_GPIO_Port, STIM_START_Pin, GPIO_PIN_SET);
				adc_flag = 0;
				HAL_ADC_Start_DMA(&hadc1, (uint32_t*)ADC_RX_BUFFER, ADC_RX_BUFFER_LEN);
				if ((pulseW >= PULSE_WIDTH_50US) && (pulseW < PULSE_WIDTH_250US))
					pulseW += 50;
			}
			*/
			/* Decrease Pulse Width
			*/
			else if (rx_buff_usart[0] == '6')
			{
				HAL_GPIO_WritePin(STIM_START_GPIO_Port, STIM_START_Pin, GPIO_PIN_SET);
				adc_flag = 0;
				HAL_ADC_Start_DMA(&hadc1, (uint32_t*)ADC_RX_BUFFER, ADC_RX_BUFFER_LEN);

				if ((pulseW > PULSE_WIDTH_50US) && (pulseW <= PULSE_WIDTH_250US))
				{
					if (freq == 1)
						pulseW = PULSE_WIDTH_150US;
					else if (freq == 2)
					{
							pulseW = PULSE_WIDTH_100US;
						if (pulseW == PULSE_WIDTH_50US)
							pulseW = PULSE_WIDTH_100US;
					}
					else
						pulseW -= 50;
				}
			}
			/*
			else if ((rx_buff_usart1[5] == 0x1E) && (rx_buff_usart1[6] == 0x1E) && (rx_buff_usart1[7] == 0x1E) && (rx_buff_usart1[8] == 0x1E))
			{
				HAL_GPIO_WritePin(STIM_START_GPIO_Port, STIM_START_Pin, GPIO_PIN_SET);
				adc_flag = 0;
				HAL_ADC_Start_DMA(&hadc1, (uint32_t*)ADC_RX_BUFFER, ADC_RX_BUFFER_LEN);
				if ((pulseW > PULSE_WIDTH_50US) && (pulseW <= PULSE_WIDTH_250US))
					pulseW -= 50;
			}
			*/
			DDS_Start(freq, pulseW, dacVal);
			
			sprintf(freq_s, 		"FREQ:%d Hz, ", freq);
			HAL_UART_Transmit(&huart1, (const uint8_t *)freq_s, strlen(freq_s), 200);
			if (freq == 1)
			{
				sprintf(pulseW_s, 	"PW:%d us, ", pulseW+50);
			}
			else if (freq == 2)
			{
				if (pulseW == 250)
				{
					sprintf(pulseW_s, 	"PW:%d us, ", pulseW-50);
				}
				else if (pulseW == 200)
				{
					sprintf(pulseW_s, 	"PW:%d us, ", pulseW);
				}
				else if (pulseW == 150)
				{
					sprintf(pulseW_s, 	"PW:%d us, ", pulseW-50);
				}
				else if (pulseW == 100)
				{
					sprintf(pulseW_s, 	"PW:%d us, ", pulseW);
				}
			}
			else
			{
				sprintf(pulseW_s, 	"PW:%d us, ", pulseW);
			}
			HAL_UART_Transmit(&huart1, (const uint8_t *)pulseW_s, strlen(pulseW_s), 200);
			sprintf(current_s, 	"CURRENT:%d mA", current);
			HAL_UART_Transmit(&huart1, (const uint8_t *)current_s, strlen(current_s), 200);
			//sprintf(dacVal_s, "dacV: %d\r\n", dacVal);
			//HAL_UART_Transmit(&huart1, (const uint8_t *)dacVal_s, strlen(dacVal_s), 200);

			HAL_UART_Transmit(&huart2, (const uint8_t *)tx_buff_usart2, strlen(tx_buff_usart2), 200);

			/*
			sprintf(freq_s, "\nFreq: %d Hz\r\n", freq);
			HAL_UART_Transmit(&huart1, (const uint8_t *)freq_s, strlen(freq_s), 200);
			sprintf(pulseW_s, "PW: %d us\r\n", pulseW);
			HAL_UART_Transmit(&huart1, (const uint8_t *)pulseW_s, strlen(pulseW_s), 200);
			sprintf(current_s, "Cur: %d mA\r\n", current);
			HAL_UART_Transmit(&huart1, (const uint8_t *)current_s, strlen(current_s), 200);
			sprintf(dacVal_s, "dacV: %d\r\n", dacVal);
			HAL_UART_Transmit(&huart1, (const uint8_t *)dacVal_s, strlen(dacVal_s), 200);

			HAL_UART_Transmit(&huart2, (const uint8_t *)tx_buff_usart2, strlen(tx_buff_usart2), 200);
			*/
		}
	}
	

//	else if (huart->Instance == USART2) 
//	{
//    // USART2
//		sprintf(tx_buff_usart2_s, "Status: %d \r\n", tx_buff_usart2);
//		HAL_UART_Transmit(&huart2, (const uint8_t *)tx_buff_usart2_s, strlen(tx_buff_usart2_s), 200);
//	}
	
}

/**
  * @brief Find the minimum value within an array
  * @param  array[]: an array to be checked
  * @param  length: the length of an array
  * @retval Minimum component of an array
  */
uint16_t FIND_MIN(uint16_t array[], uint16_t length)
{
  uint16_t min;
  min = array[0];

  for (i = 0; i < length; i++)
  {
    if (array[i] < min)
    {
      min = array[i];
    }
  }

  return min;
}

void HAL_ADC_ConvHalfCpltCallback(ADC_HandleTypeDef* hadc)
{
//	__NOP();
}

void HAL_ADC_ConvCpltCallback(ADC_HandleTypeDef* hadc)
{
//	__NOP();
	//adc_flag = 0;
	sysStatus = Start;
	adcVal = FIND_MIN(ADC_RX_BUFFER, ADC_RX_BUFFER_LEN);
	//adcVal = ADC_RX_BUFFER[0];
	if ((adcVal <= ADCVAL_THD) || (current <= 10 && adcVal <= 1500))
	{
		//adc_flag = 0;
		adc_flag = 1;
		//HAL_GPIO_WritePin(STIM_START_GPIO_Port, STIM_START_Pin, GPIO_PIN_SET);
		//HAL_GPIO_WritePin(ELCTRD_CONN_GPIO_Port, ELCTRD_CONN_Pin, GPIO_PIN_SET);
		//HAL_GPIO_WritePin(ELCTRD_DISC_GPIO_Port, ELCTRD_DISC_Pin, GPIO_PIN_RESET);
	}
	
	if (adc_flag)
	{
		HAL_ADC_Stop_DMA(&hadc1);
		//adc_flag = 0;
		current = 0;
		dacVal = DACVAL_0MA;
		//sysStatus = Stop;
		//HAL_GPIO_WritePin(STIM_START_GPIO_Port, STIM_START_Pin, GPIO_PIN_RESET);
		//HAL_GPIO_WritePin(ELCTRD_CONN_GPIO_Port, ELCTRD_CONN_Pin, GPIO_PIN_RESET);
		//HAL_GPIO_WritePin(ELCTRD_DISC_GPIO_Port, ELCTRD_DISC_Pin, GPIO_PIN_SET);
		DDS_Stop();
	}
}

/* USER CODE END 4 */

/**
  * @brief  This function is executed in case of error occurrence.
  * @retval None
  */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */
  __disable_irq();
  while (1)
  {
  }
  /* USER CODE END Error_Handler_Debug */
}

#ifdef  USE_FULL_ASSERT
/**
  * @brief  Reports the name of the source file and the source line number
  *         where the assert_param error has occurred.
  * @param  file: pointer to the source file name
  * @param  line: assert_param error line source number
  * @retval None
  */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */
